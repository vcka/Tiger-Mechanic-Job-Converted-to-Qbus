QBCore = nil
TriggerEvent('QBCore:GetObject', function(obj) QBCore = obj end)

RegisterServerEvent('end_mechanicjob:fetchMechShops')
AddEventHandler('end_mechanicjob:fetchMechShops', function()
    local xPlayers = QBCore.Functions.GetPlayers()
    local players  = {}
    local DataFected = false
	for i = 1, #xPlayers, 1 do
		local xPlayer = QBCore.Functions.GetPlayer(xPlayers[i])
		table.insert(players, { source = xPlayer.PlayerData.source, citizenid = xPlayer.PlayerData.citizenid, shopID = 0 })
    end
    exports['ghmattimysql']:execute("SELECT * FROM end_mechanic", {}, function(results)
        if #results > 0 then 
            for l,ply in pairs(players) do
                for k,v in pairs(results) do
                    if ply.citizenid == v.citizenid then
                        ply.shopID = v.shopID
                        if k == #results then DataFected = true end
                    end
                end
            end
        else
            DataFected = true
        end
    end)
    while not DataFected do Wait(5) end
    local plyShopID = 0
    for k,v in pairs(players) do if v.shopID > 0 then plyShopID = v.shopID else plyShopID = 0 end
        TriggerClientEvent('end_mechanicjob:fetchMechShopsCL', v.source, v.shopID)
    end
end)

-- Purchase Mech Shop:
QBCore.Functions.CreateCallback('end_mechanicjob:buyMechShop',function(source, cb, id, val, name)
    local xPlayer = QBCore.Functions.GetPlayer(source)
    local citizenid = xPlayer.PlayerData.citizenid
    local money = 0
    if Config.PayMechShopWithCash then
        money = xPlayer.PlayerData.money["cash"]
    else
        money = xPlayer.PlayerData.money["bank"]
    end
	if money >= val.price then
		if Config.PayMechShopWithCash then
			xPlayer.Functions.RemoveMoney("cash", val.price)
		else
			xPlayer.Functions.RemoveMoney('bank', val.price)
		end

        QBCore.Functions.ExecuteSql(true, "INSERT INTO `end_mechanic` (`citizenid`, `shopID`, `name`) VALUES ('"..citizenid.."', '"..id.."', '"..name.."')")
        cb(true)
    else
        cb(false)
    end
end)

-- Sell Mech Shop:
QBCore.Functions.CreateCallback('end_mechanicjob:sellMechShop',function(source, cb, id, val, sellPrice)
    local xPlayer = QBCore.Functions.GetPlayer(source)
    exports['ghmattimysql']:execute("SELECT shopID FROM end_mechanic WHERE citizenid = @citizenid", {['@citizenid'] = xPlayer.PlayerData.citizenid}, function(data)
        if data[1].shopID ~= nil then 
            if data[1].shopID == id then
                exports['ghmattimysql']:execute("DELETE FROM end_mechanic WHERE shopID=@shopID", {['@shopID'] = id}) 
                if Config.RecieveSoldMechShopCash then
                    xPlayer.Functions.AddMoney("cash", sellPrice)
                else
                    xPlayer.addAccountMoney('bank',sellPrice)
                end
                cb(true)
            else
                cb(false)
            end
        end
    end)
end)

-- Reanme Mech Shop:
QBCore.Functions.CreateCallback('end_mechanicjob:renameMechShop',function(source, cb, id, val, name)
    local xPlayer = QBCore.Functions.GetPlayer(source)
    exports['ghmattimysql']:execute("SELECT shopID FROM end_mechanic WHERE citizenid = @citizenid", {['@citizenid'] = xPlayer.PlayerData.citizenid}, function(data)
        if data[1].shopID ~= nil then 
            if data[1].shopID == id then
                exports.ghmattimysql:executeSync("UPDATE end_mechanic SET name = @name WHERE shopID = @shopID", {
                    ['@name'] = name,
                    ['@shopID'] = id
                })
                cb(true)
            else
                cb(false)
            end
        end
    end)
end)

-- Get Employees:
QBCore.Functions.CreateCallback('end_mechanicjob:getEmployees',function(source, cb, id)
    local xPlayer = QBCore.Functions.GetPlayer(source)
    local dataFected = false
    local shopEmployees = {}
    local noEmployees = false
    exports['ghmattimysql']:execute("SELECT employees FROM end_mechanic WHERE shopID = @shopID", {['@shopID'] = id}, function(data)
        if data[1].employees ~= nil then
            local employees = json.decode(data[1].employees)
            if #employees > 0 then
                for k,v in pairs(employees) do 
                    exports['ghmattimysql']:execute('SELECT * FROM players WHERE citizenid = @citizenid', {['@citizenid'] = v.citizenid}, function (info)
                        for j,l in pairs(info) do 
                            if v.citizenid == l.citizenid then 
                                table.insert(shopEmployees,{citizenid = v.citizenid, firstname = l.firstname, lastname = l.lastname})
                                if k == #employees then 
                                    dataFected = true
                                end
                            end
                        end
                    end)
                end
            else
                noEmployees = true
                dataFected = true
            end
        end 
    end)
    while not dataFected do
        Citizen.Wait(1)
    end
    if dataFected then
        if noEmployees then cb(nil) else cb(shopEmployees) end
    end
end)

-- Fire Employee:
RegisterServerEvent('end_mechanicjob:fireEmployee')
AddEventHandler('end_mechanicjob:fireEmployee', function(id, plyIdentifier)
    local xPlayer = QBCore.Functions.GetPlayer(source)
    exports['ghmattimysql']:execute("SELECT * FROM end_mechanic WHERE shopID = @shopID", {['@shopID'] = id}, function(data)
        if data[1].employees ~= nil then
            local employees = json.decode(data[1].employees)
            if #employees > 0 then 
                for k,v in pairs(employees) do 
                    if plyIdentifier == v.citizenid then 
                        table.remove(employees, k)
                        exports.ghmattimysql:executeSync("UPDATE end_mechanic SET employees = @employees WHERE shopID = @shopID", {
                            ['@employees'] = json.encode(employees),
                            ['@shopID'] = id
                        })
                        local xTarget = QBCore.Functions.GetPlayerentifier(plyIdentifier)
                        xTarget.setJob("unemployed", 0)
                        TriggerClientEvent('end_mechanicjob:ShowNotifyESX', xTarget.source, Lang['mech_employee_fired'])
                        break
                    end
                end
            end
        end
    end)
end)


-- Callback to Get online players:
QBCore.Functions.CreateCallback('end_mechanicjob:getOnlinePlayers', function(source, cb)
	local fetchedPlayers = GetOnlinePlayers()
	cb(fetchedPlayers)
end)

-- Reqruit Employee:
RegisterServerEvent('end_mechanicjob:reqruitEmployee')
AddEventHandler('end_mechanicjob:reqruitEmployee', function(id, plyIdentifier, name)
    local xPlayer = QBCore.Functions.GetPlayer(source)
    local loopDone = false
    local identifierMatch = false
    local noEmployees = false
    exports['ghmattimysql']:execute("SELECT employees FROM end_mechanic WHERE shopID = @shopID", {['@shopID'] = id}, function(data)
        if data[1].employees ~= nil then 
            local employees = json.decode(data[1].employees)
            if #employees > 0 then
                for k,v in pairs(employees) do 
                    if plyIdentifier == v.citizenid then
                        identifierMatch = true
                        break
                    else
                        if k == #employees then 
                            loopDone = true
                        end
                    end
                end
            else
                noEmployees = true
                loopDone = true
            end
        end
    end)
    while not loopDone do 
        Citizen.Wait(1)
    end
    if identifierMatch then 
        TriggerClientEvent('end_mechanicjob:ShowNotifyESX', xPlayer.PlayerData.source, Lang['already_hired'])
    end
    if loopDone then
        if noEmployees then
            exports['ghmattimysql']:execute("SELECT * FROM end_mechanic WHERE shopID = @shopID", {['@shopID'] = id}, function(data)
                for _,y in pairs(data) do 
                    local employees = {}
                    table.insert(employees,{citizenid = plyIdentifier})
                    exports.ghmattimysql:executeSync("UPDATE end_mechanic SET employees = @employees WHERE shopID = @shopID", {
                        ['@employees'] = json.encode(employees),
                        ['@shopID'] = id
                    })
                    TriggerClientEvent('end_mechanicjob:ShowNotifyESX', xPlayer.PlayerData.source, (Lang['you_recruited_x']:format(name)))
                    local xTarget = QBCore.Functions.GetPlayerentifier(plyIdentifier)
                    xTarget.setJob("mechanic")
                    TriggerClientEvent('end_mechanicjob:ShowNotifyESX', xTarget.source, Lang['you_have_been_recruited'])
                    break
                end
            end)
        else
            if not identifierMatch then
                exports['ghmattimysql']:execute("SELECT * FROM end_mechanic WHERE shopID = @shopID", {['@shopID'] = id}, function(data)
                    for _,y in pairs(data) do 
                        local employees = json.decode(y.employees)
                        table.insert(employees,{citizenid = plyIdentifier})
                        exports.ghmattimysql:executeSync("UPDATE end_mechanic SET employees = @employees WHERE shopID = @shopID", {
                            ['@employees'] = json.encode(employees),
                            ['@shopID'] = id
                        })
                        TriggerClientEvent('end_mechanicjob:ShowNotifyESX', xPlayer.PlayerData.source, (Lang['you_recruited_x']:format(name)))
                        local xTarget = QBCore.Functions.GetPlayerentifier(plyIdentifier)
                        xTarget.setJob("mechanic", 0)
                        TriggerClientEvent('end_mechanicjob:ShowNotifyESX', xTarget.source, Lang['you_have_been_recruited'])
                        break
                    end
                end)
            end
        end
    end
end)

-- Withdraw Account Money:
RegisterServerEvent('end_mechanicjob:withdrawMoney')
AddEventHandler('end_mechanicjob:withdrawMoney', function(id, amount)
    local xPlayer = QBCore.Functions.GetPlayer(source)
    local accountMoney = 0
    exports['ghmattimysql']:execute("SELECT money FROM end_mechanic WHERE shopID = @shopID", {['@shopID'] = id}, function(data)
        if data[1].money ~= nil then 
            accountMoney = data[1].money
        end
        if amount <= accountMoney then 
            exports.ghmattimysql:executeSync("UPDATE end_mechanic SET money = @money WHERE shopID = @shopID", {
                ['@money'] = (accountMoney - amount),
                ['@shopID'] = id
            })
            xPlayer.Functions.AddMoney("cash", amount)
            TriggerClientEvent('end_mechanicjob:ShowNotifyESX', xPlayer.PlayerData.source, (Lang['you_withdrew_x_amount']:format(amount)))
        else
            TriggerClientEvent('end_mechanicjob:ShowNotifyESX', xPlayer.PlayerData.source, Lang['withdrawal_denied'])
        end
    end)
end)

-- Deposit Account Money:
RegisterServerEvent('end_mechanicjob:depositMoney')
AddEventHandler('end_mechanicjob:depositMoney', function(id, amount)
    local xPlayer = QBCore.Functions.GetPlayer(source)
    local accountMoney = 0
    exports['ghmattimysql']:execute("SELECT money FROM end_mechanic WHERE shopID = @shopID", {['@shopID'] = id}, function(data)
        if data[1].money ~= nil then 
            accountMoney = data[1].money
        end
        local plyMoney = xPlayer.PlayerData.money["cash"]
        if plyMoney >= amount then 
            exports.ghmattimysql:executeSync("UPDATE end_mechanic SET money = @money WHERE shopID = @shopID", {
                ['@money'] = (accountMoney + amount),
                ['@shopID'] = id
            })
            xPlayer.Functions.RemoveMoney("cash", amount)
            TriggerClientEvent('end_mechanicjob:ShowNotifyESX', xPlayer.PlayerData.source, (Lang['you_deposited_x_amount']:format(amount)))
        else
            TriggerClientEvent('end_mechanicjob:ShowNotifyESX', xPlayer.PlayerData.source, Lang['not_enough_money'])
        end
    end)
end)

-- Check Storage Access:
QBCore.Functions.CreateCallback('end_mechanicjob:checkAccess',function(source, cb, id)
    local xPlayer = QBCore.Functions.GetPlayer(source)
    exports['ghmattimysql']:execute("SELECT * FROM end_mechanic WHERE shopID = @shopID", {['@shopID'] = id}, function(data)
        for shops,columns in pairs(data) do 
            if columns.shopID == id then 
                    cb(true)
                    break
                if columns.employees ~= nil then 
                    local employees = json.decode(columns.employees)
                    if #employees > 0 then 
                        for k,v in pairs(employees) do 
                            if xPlayer.PlayerData.citizenid() == v.citizenid then 
                                cb(true)
                                break
                            end
                        end
                    else
                        cb(false)
                    end
                end
            end
        end
    end)
end)

-- Get User Inventory:
QBCore.Functions.CreateCallback('end_mechanicjob:getUserInventory', function(source, cb)
    local xPlayer = QBCore.Functions.GetPlayer(source)
    local inventoryItems = xPlayer.PlayerData.items
    cb(inventoryItems)
end)

-- Deposit Items into Storage:
RegisterServerEvent('end_mechanicjob:depositItem')
AddEventHandler('end_mechanicjob:depositItem', function(item, amount, id)
    local xPlayer = QBCore.Functions.GetPlayer(source)
    local addItem = item
    local itemAdded = false
    if xPlayer.Functions.GetItemByName(addItem).amount >= amount then

        exports['ghmattimysql']:execute("SELECT storage FROM end_mechanic WHERE shopID = @shopID", {['@shopID'] = id}, function(data)
            if data[1].storage ~= nil then
                local storage = json.decode(data[1].storage)
                if #storage > 0 then 
                    for k,v in ipairs(storage) do 
                        if v.item == addItem then
                            v.count = (v.count + amount)
                            itemAdded = true
                            break
                        else
                            if k == #storage then
                                if Config.ItemLabelESX then
                                    table.insert(storage, {item = addItem, count = amount, label = addItem.label})
                                else
                                    table.insert(storage, {item = addItem, count = amount, label = tostring(addItem)})
                                end
                                itemAdded = true
                                break
                            end
                        end
                    end
                    while not itemAdded do Citizen.Wait(1) end
                    if itemAdded then 
                        exports.ghmattimysql:executeSync("UPDATE end_mechanic SET storage = @storage WHERE shopID = @shopID", {
                            ['@storage'] = json.encode(storage),
                            ['@shopID'] = id
                        })
                        xPlayer.Functions.RemoveItem(addItem, amount)
                        local itemLabel = ''
                        if Config.ItemLabelESX then itemLabel = addItem.label else itemLabel = tostring(addItem) end
                        TriggerClientEvent('end_mechanicjob:ShowNotifyESX', xPlayer.PlayerData.source, (Lang['storage_deposited_x']:format(amount, itemLabel)))
                    end
                else
                    storage = {}
                    if Config.ItemLabelESX then
                        table.insert(storage, {item = addItem, count = amount, label = addItem.label})
                    else
                        table.insert(storage, {item = addItem, count = amount, label = tostring(addItem)})
                    end
                    exports.ghmattimysql:executeSync("UPDATE end_mechanic SET storage = @storage WHERE shopID = @shopID", {
                        ['@storage'] = json.encode(storage),
                        ['@shopID'] = id
                    })   
                    xPlayer.Functions.RemoveItem(addItem, amount)
                    local itemLabel = ''
                    if Config.ItemLabelESX then itemLabel = addItem.label else itemLabel = tostring(addItem) end
                    TriggerClientEvent('end_mechanicjob:ShowNotifyESX', xPlayer.PlayerData.source, (Lang['storage_deposited_x']:format(amount, itemLabel)))
                end
            end
        end)
    else
        TriggerClientEvent('end_mechanicjob:ShowNotifyESX', xPlayer.PlayerData.source, Lang['not_enough_items'])
    end
end)

-- Get Storage Inventory:
QBCore.Functions.CreateCallback('end_mechanicjob:getStorageInventory', function(source, cb, id)
	local xPlayer = QBCore.Functions.GetPlayer(source)
    local dataFected = false
    local storageInv = {}
    exports['ghmattimysql']:execute("SELECT storage FROM end_mechanic WHERE shopID = @shopID", {['@shopID'] = id}, function(data)
        if data[1].storage ~= nil then
            local storage = json.decode(data[1].storage)
            if #storage > 0 then 
                for k,v in pairs(storage) do 
                    table.insert(storageInv,{item = v.item, count = v.count, label = v.label})
                    if k == #storage then 
                        dataFected = true
                    end
                end
            else
                cb(nil)
            end
        end
    end)
    while not dataFected do
        Citizen.Wait(1)
    end
    if dataFected then 
        cb(storageInv)
    end
end)

QBCore.Functions.CreateCallback('end_mechanicjob:getTakenShops', function(source, cb)
    local xPlayer = QBCore.Functions.GetPlayer(source)
if Player then
    exports['ghmattimysql']:execute("SELECT money FROM end_mechanic WHERE citizenid = @citizenid", {['@citizenid'] = xPlayer.PlayerData.citizenid}, function(data)
        if data[1].money ~= nil then
            local account = json.decode(data[1].money)
            cb(account)
        else
            cb(nil)
        end
    end)
end
end)

QBCore.Functions.CreateCallback('end_mechanicjob:getShopAccounts', function(source, cb)
    local xPlayer = QBCore.Functions.GetPlayer(source)
    exports['ghmattimysql']:execute("SELECT money FROM end_mechanic WHERE citizenid = @citizenid", {['@citizenid'] = xPlayer.PlayerData.citizenid}, function(data)
        if data[1].money ~= nil then
            local account = json.decode(data[1].money)
            cb(account)
        else
            cb(nil)
        end
    end)
end)

RegisterServerEvent('end_mechanicjob:JobReward')
AddEventHandler('end_mechanicjob:JobReward', function()
    local xPlayer = QBCore.Functions.GetPlayer(source)
    xPlayer.Functions.AddMoney("cash", Config.Payout)
end)


-- Withdraw Items from Storage:
RegisterServerEvent('end_mechanicjob:withdrawItem')
AddEventHandler('end_mechanicjob:withdrawItem', function(item, amount, id)
    local xPlayer = QBCore.Functions.GetPlayer(source)
    local removeItem = item
    exports['ghmattimysql']:execute("SELECT storage FROM end_mechanic WHERE shopID = @shopID", {['@shopID'] = id}, function(data)
        if data[1].storage ~= nil then
            local storage = json.decode(data[1].storage)
            for k,v in pairs(storage) do
                if removeItem == v.item then
                    v.count = (v.count - amount)
                    Citizen.Wait(250)
                    if v.count == 0 then
                        table.remove(storage, k)
                    end
                    exports.ghmattimysql:executeSync("UPDATE end_mechanic SET storage = @storage WHERE shopID = @shopID", {
                        ['@storage'] = json.encode(storage),
                        ['@shopID'] = id
                    })
                    xPlayer.addInventoryItem(removeItem, amount)
                    local itemLabel = ''
                    if Config.ItemLabelESX then itemLabel = ESX.GetItemLabel(removeItem) else itemLabel = tostring(removeItem) end
                    TriggerClientEvent('end_mechanicjob:ShowNotifyESX', xPlayer.PlayerData.source, (Lang['storage_withdrew_x']:format(amount, itemLabel)))
                end
            end
        end
    end)
end)

-- Craft Items:
RegisterServerEvent('end_mechanicjob:craftItem')
AddEventHandler('end_mechanicjob:craftItem', function(item_label, item_name, item_recipe, id, val)
    local xPlayer = QBCore.Functions.GetPlayer(source)
    local removeItems = {}
    local loopDone = false
    local hasRecipeItems = false
    for k,v in ipairs(item_recipe) do
		local material = Config.Materials[v.id]
        if xPlayer.Functions.GetItemByName(material.item) then
            table.insert(removeItems, {item = material.item})
        else
            loopDone = true
            hasRecipeItems = false
            break
        end
        if k == #item_recipe then 
            loopDone = true
            hasRecipeItems = true
        end
    end
    while not loopDone do 
        Citizen.Wait(1)
    end
    if hasRecipeItems then 
        for k,v in pairs(removeItems) do
            xPlayer.Functions.RemoveItem(v.item, v.amount)
        end
        xPlayer.addInventoryItem(item_name, 1)
    else
        TriggerClientEvent('end_mechanicjob:ShowNotifyESX', xPlayer.PlayerData.source, Lang['not_enough_materials'])
    end
end)

-- Billing:
RegisterServerEvent('end_mechanicjob:sendBill')
AddEventHandler('end_mechanicjob:sendBill',function(target, amount)
	local xPlayer = QBCore.Functions.GetPlayer(source)
    local xPlayers = QBCore.Functions.GetPlayers()
    if amount ~= nil then
        if amount >= 0 then
            for i = 1, #xPlayers, 1 do
                local tPlayer = QBCore.Functions.GetPlayer(xPlayers[i])
                if tPlayer.source == target then
                    tPlayer.Functions.RemoveMoney('bank', tonumber(amount))
                    TriggerClientEvent('end_mechanicjob:ShowNotifyESX', tPlayer.source, "You paid the invoice of ~g~$"..amount.."~s~ to the mechanic.")
                    xPlayer.Functions.AddMoney('bank', tonumber(amount))
                    TriggerClientEvent('end_mechanicjob:ShowNotifyESX', xPlayer.PlayerData.source, "You received payment from the invoice of ~g~$"..amount)
                    break
                end
            end
        end
    end
end)

-- Repair Kits:
Citizen.CreateThread(function()
	for k,v in pairs(Config.RepairKits) do 
		QBCore.Functions.CreateUseableItem(v.item, function(source)
			local xPlayer = QBCore.Functions.GetPlayer(source)
			TriggerClientEvent('end_mechanicjob:useRepairKit', xPlayer.PlayerData.source, k, v)
		end)
	end
end)

-- Remove item event:
RegisterServerEvent('end_mechanicjob:removeItem')
AddEventHandler('end_mechanicjob:removeItem', function(item, amount)
    local xPlayer = QBCore.Functions.GetPlayer(source)
    xPlayer.Functions.RemoveItem(item, amount)
end)

-- Get inventory item:
QBCore.Functions.CreateCallback('end_mechanicjob:getInventoryItem',function(source, cb, item)
    local xPlayer = QBCore.Functions.GetPlayer(source)
    local hasItem = xPlayer.Functions.GetItemByName(item)
    if hasItem then cb(true) else cb(false) end
end)

Citizen.CreateThread(function()
	for k,v in pairs(Config.BodyParts) do 
		QBCore.Functions.CreateUseableItem(v.item, function(source)
			local xPlayer = QBCore.Functions.GetPlayer(source)
			TriggerClientEvent('end_mechanicjob:installBodyPartCL', xPlayer.PlayerData.source, k, v)
		end)
	end
end)

function GetOnlinePlayers()
    local xPlayers = QBCore.Functions.GetPlayers()
	local players  = {}
	for i=1, #xPlayers, 1 do
		local xPlayer = QBCore.Functions.GetPlayer(xPlayers[i])
		table.insert(players, {
			source     = xPlayer.PlayerData.source,
			citizenid = xPlayer.PlayerData.citizenid,
			name       = xPlayer.PlayerData.charinfo.firstname
		})
    end
    return players
end

-- Get Materials for Health Part Repair:
QBCore.Functions.CreateCallback('end_mechanicjob:getMaterialsForHealthRep',function(source, cb, plate, degName, materials, newValue, addValue, vehOnLift)
    local xPlayer = QBCore.Functions.GetPlayer(source)
    -- Get & Remove materials:
    local removeItems = {}
    local loopDone = false
    local hasMaterials = false
    for k,v in ipairs(materials) do
        local items = Config.Materials[v.id]
        local multiplier = math.floor(addValue)
        local reqAmount = (v.qty * multiplier)
        if xPlayer.Functions.GetItemByName(items.item).count >= reqAmount then
            table.insert(removeItems, {item = items.item, amount = reqAmount})
        else
            loopDone = true
            hasMaterials = false
            break
        end
        if k == #materials then 
            loopDone = true
            hasMaterials = true
        end
    end
    while not loopDone do 
        Citizen.Wait(1)
    end
    if hasMaterials then 
        for k,v in pairs(removeItems) do
            xPlayer.Functions.RemoveItem(v.item, v.amount)
        end
        cb(true)
    else
        cb(false)
    end
end)


-- Update Vehicle Degradation:
RegisterServerEvent('end_mechanicjob:updateVehDegradation') 
AddEventHandler('end_mechanicjob:updateVehDegradation', function(plate, label, degName, vehOnLift)
    local xPlayer = QBCore.Functions.GetPlayer(source)
    exports['ghmattimysql']:execute("SELECT health FROM player_vehicles WHERE plate=@plate",{['@plate'] = plate}, function(data) 
        if #data > 0 then
            if data[1].health ~= nil then 
                local health = json.decode(data[1].health)
                if #health > 0 then 
                    for k,v in pairs(health) do
                        if v.part == degName then
                            local updateValue = vehOnLift[plate].health[degName].value
                            if v.part == "engine" then
                                v.value = math.floor(updateValue * 10 * 10)
                            else
                                v.value = math.floor(updateValue * 10)
                            end
                            exports.ghmattimysql:executeSync("UPDATE player_vehicles SET health = @health WHERE plate = @plate", {
                                ['@health'] = json.encode(health),
                                ['@plate'] = plate
                            })
                            TriggerClientEvent('end_mechanicjob:ShowNotifyESX', xPlayer.PlayerData.source, (Lang['you_rep_health_part']:format(degName, updateValue)))
                            break
                        end
                    end
                end
            end 
        end
	end)
end)

-- Degrade Vehicle Degradation:
RegisterServerEvent('end_mechanicjob:degradeVehHealth') 
AddEventHandler('end_mechanicjob:degradeVehHealth', function(plate, damageArray)
    local xPlayer = QBCore.Functions.GetPlayer(source)
    exports['ghmattimysql']:execute("SELECT health FROM player_vehicles WHERE plate=@plate",{['@plate'] = plate}, function(data) 
        if #data > 0 then
            if data[1].health ~= nil then 
                local health = json.decode(data[1].health)
                if #health > 0 then 
                    for k,v in pairs(health) do
                        local part = damageArray[v.part]
                        if part ~= nil then
                            if v.part == part.degName then 
                                local degVal = part.degValue
                                local oldVal = v.value
                                v.value = (oldVal - degVal)
                                exports.ghmattimysql:executeSync("UPDATE player_vehicles SET health = @health WHERE plate = @plate", {
                                    ['@health'] = json.encode(health),
                                    ['@plate'] = plate
                                })
                                TriggerClientEvent('end_mechanicjob:ShowNotifyESX', xPlayer.PlayerData.source, part.label.." took damage. Degradation by: "..round(degVal/10,2)..". New Value: "..round(v.value/10,2))
                            end
                        end
                    end
                else
                    local healthJSON = {}
                    for k,v in ipairs(Config.HealthParts) do
                        local partVal = 100
                        if v.degName == "engine" then partVal = 1000 end
                        table.insert(healthJSON, {part = v.degName, value = partVal})
                        if k == #Config.HealthParts then 
                            exports.ghmattimysql:executeSync("UPDATE player_vehicles SET health = @health WHERE plate = @plate", {
                                ['@health'] = json.encode(healthJSON),
                                ['@plate'] = plate
                            })
                            Wait(1000)
                            exports['ghmattimysql']:execute("SELECT health FROM player_vehicles WHERE plate=@plate",{['@plate'] = plate}, function(data) 
                                local health = json.decode(data[1].health)
                                if #health > 0 then 
                                    for k,v in pairs(health) do
                                        local part = damageArray[v.part]
                                        if part ~= nil then
                                            if v.part == part.degName then 
                                                local degVal = part.degValue
                                                local oldVal = v.value
                                                v.value = (oldVal - degVal)
                                                exports.ghmattimysql:executeSync("UPDATE player_vehicles SET health = @health WHERE plate = @plate", {
                                                    ['@health'] = json.encode(health),
                                                    ['@plate'] = plate
                                                })
                                                TriggerClientEvent('end_mechanicjob:ShowNotifyESX', xPlayer.PlayerData.source, part.label.." took damage. Degradation by: "..round(degVal/10,2)..". New Value: "..round(v.value/10,2))
                                            end
                                        end
                                    end
                                end
                            end)
                        end
                    end
                end
            end 
        end
	end)
end)

RegisterServerEvent('end_mechanicjob:JobReward')
AddEventHandler('end_mechanicjob:JobReward',function(payout)
    local xPlayer = QBCore.Functions.GetPlayer(source)
    local cash = math.random(payout.min,payout.max)
    xPlayer.Functions.AddMoney("cash", cash)
    TriggerClientEvent('end_mechanicjob:ShowNotifyESX', xPlayer.PlayerData.source, (Lang['npc_job_cash_reward']:format(cash)))
end)



